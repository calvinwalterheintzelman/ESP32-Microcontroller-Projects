from machine import Pin
import time

switch1 = Pin(34, Pin.IN, Pin.PULL_DOWN)
switch2 = Pin(39, Pin.IN, Pin.PULL_DOWN)

red_led = Pin(26, Pin.OUT)
gre_led = Pin(25, Pin.OUT)

s1_presses = 0
s2_presses = 0

while s1_presses < 10 and s2_presses < 10:
    if switch1.value() == 1 and switch2.value() == 0:
        red_led.value(1)
        gre_led.value(0)
        s1_presses += 1
        while switch1.value() == 1 and switch2.value() == 0:
            pass
    if switch2.value() == True and switch1.value() == False:
        red_led.value(0)
        gre_led.value(1)
        s2_presses += 1
        while switch2.value() == True and switch1.value() == False:
            pass
    else:
        red_led.value(0)
        gre_led.value(0)
        
red_led.value(0)
gre_led.value(1)
t_check = time.time()

while switch1.value() == 0 and switch2.value() == 0:
    if time.time() - t_check > 0.5:
        red_led.value(not red_led.value())
        gre_led.value(not gre_led.value())
        t_check = time.time()
        
red_led.value(0)
gre_led.value(0)

print("You have successfully implemented LAB1 DEMO!!!")
    